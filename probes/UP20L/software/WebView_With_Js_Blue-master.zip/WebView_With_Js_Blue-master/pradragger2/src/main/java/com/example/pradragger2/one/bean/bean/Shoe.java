package com.example.pradragger2.one.bean.bean;

import javax.inject.Inject;

/**
 * Created by TanJieXi on 2018/7/24.
 */
public class Shoe {

    
    @Inject
    public Shoe() {

    }

    @Override
    public String toString() {
        return "鞋子";
    }
}
