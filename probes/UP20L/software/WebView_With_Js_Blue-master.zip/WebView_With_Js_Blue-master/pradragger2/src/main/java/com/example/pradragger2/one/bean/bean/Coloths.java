package com.example.pradragger2.one.bean.bean;

/**
 * Created by TanJieXi on 2018/7/24.
 */
public class Coloths {
    private Cloth color;

    public Coloths(Cloth color) {
        this.color = color;
    }

    public Cloth getColor() {
        return color;
    }

    public void setColor(Cloth color) {
        this.color = color;
    }
}
