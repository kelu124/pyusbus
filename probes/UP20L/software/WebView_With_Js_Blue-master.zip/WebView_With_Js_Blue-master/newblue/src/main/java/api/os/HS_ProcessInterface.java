package api.os;

/*! @brief 图像处理
 *  @note  需要改变某个算法,只需要实现对应的接口即可
*/
public class HS_ProcessInterface {

}
