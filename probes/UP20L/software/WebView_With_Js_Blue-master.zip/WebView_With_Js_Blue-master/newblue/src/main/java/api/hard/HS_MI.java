package api.hard;

public class HS_MI {
    /*! @brief  获取机械指数
     *  @return 机械指数
    */
    public native double getMI();
}
