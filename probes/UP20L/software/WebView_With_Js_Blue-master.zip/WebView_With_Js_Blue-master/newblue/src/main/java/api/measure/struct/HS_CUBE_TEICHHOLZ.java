package api.measure.struct;

public class HS_CUBE_TEICHHOLZ {
	// 输入
    public double et;
    public double lvidd;
    public double lvids;
    public double rate;

    // 输出
    public double bas;
    public double edv;
    public double esv;
    public double sv;
    public double svi;
    public double co;
    public double coi;
    public double ef;
    public double fs;
    public double mvcf;

    // 输入
    public String stret;
    public String strlvidd;
    public String strlvids;
    public String strrate;

    // 输出
    public String strbas;
    public String stredv;
    public String stresv;
    public String strsv;
    public String strsvi;
    public String strco;
    public String strcoi;
    public String stref;
    public String strfs;
    public String strmvcf;
}
