package api.measure.struct;

public class HS_OBITEM2 extends HS_OBITEM {
	public int     id;
	public String type;
	public String typetable;
	public String typecomment;
	public String typemethoddef;
	public String typemethodcur;
	public boolean typereadonly;
}
