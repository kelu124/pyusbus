package com.example.newblue.bpm;

public interface ICallBackInfo {
	public void ReturnData(int gao, int di, int pul);
}
