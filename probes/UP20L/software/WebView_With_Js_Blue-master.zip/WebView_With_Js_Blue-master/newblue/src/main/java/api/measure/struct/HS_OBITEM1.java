package api.measure.struct;

public class HS_OBITEM1 extends HS_OBITEM {
	public int     id;
	public String part;
	public String parttable;
	public String partcomment;
	public int     partperioddef;
	public int     partperiodcur;
	public boolean partreadonly;
}
