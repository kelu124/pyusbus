package api.measure.struct;

public class HS_OBITEM3 extends HS_OBITEM {
	public int     id;
	public String method;
	public String methodtable;
	public String methodcomment;
	public boolean methodreadonly;
}
