package api.hard;

public class HS_TI {
    /*! @brief  获取热指数
     *  @return 热指数
    */
    public native double getTI();
}
