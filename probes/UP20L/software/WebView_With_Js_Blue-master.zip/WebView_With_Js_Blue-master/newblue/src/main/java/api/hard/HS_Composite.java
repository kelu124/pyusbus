package api.hard;

public class HS_Composite {

}
