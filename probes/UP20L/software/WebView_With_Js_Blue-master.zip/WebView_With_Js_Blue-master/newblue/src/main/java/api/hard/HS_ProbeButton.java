package api.hard;

public class HS_ProbeButton {
	/*! @brief  是否触发按键
     *  @return 是否触发
     */
	public native boolean isTriger();
}
