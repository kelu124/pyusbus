package com.example.newblue.bpm;


public interface ICallBack {
	public void call();
	
}