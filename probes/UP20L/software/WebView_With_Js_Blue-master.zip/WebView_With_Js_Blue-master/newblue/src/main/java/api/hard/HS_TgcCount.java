package api.hard;

/*! @brief TGC个数控制
 */
public class HS_TgcCount {

    /*! @brief  获取TGC个数可控制个数
     *  @return TGC个数可控制个数
    */
	public native int getSize();
}
