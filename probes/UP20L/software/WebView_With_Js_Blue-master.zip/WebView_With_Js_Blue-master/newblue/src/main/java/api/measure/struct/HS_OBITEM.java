package api.measure.struct;

public class HS_OBITEM {
	public int   level;
}
