package api.measure.struct;

public class HS_BindMath {
	public double m_measureCoef;	// 测量系数(pixels/mm)---用于测量B图距离
	public long[] m_measureStamp;	// M时间戳---------------用于测量M图时间
}
