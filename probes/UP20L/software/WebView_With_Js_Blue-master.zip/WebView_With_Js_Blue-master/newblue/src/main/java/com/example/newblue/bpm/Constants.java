package com.example.newblue.bpm;

public class Constants {
	public static final String CONTEC08A = "NIBP010095";
	
	public static final String CONTEC08A1 = "NIBP031217";

	public static final String CMS50EW = "CMS50EW";
	
	public static final String CMS50EW1 = "SpO201";
	
	public static final Object DEVICE_NAME1 = CONTEC08A;

	public static final Object DEVICE_NAME2 = CONTEC08A1;

}
