package api.measure.struct;

public class HS_OBITEM4 extends HS_OBITEM {
	public int     id;
	public double  value;
	public int     l_sd;
	public int     week;
	public int     day;
	public int     r_sd;
	public boolean datareadonly;
}
