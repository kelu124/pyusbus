package com.example.stu.demo3;

import android.app.Application;

/**
 * Created by TanJieXi on 2018/3/26.
 */

public class App extends Application {

    @Override
    public void onCreate() {
        super.onCreate();


    }
}
