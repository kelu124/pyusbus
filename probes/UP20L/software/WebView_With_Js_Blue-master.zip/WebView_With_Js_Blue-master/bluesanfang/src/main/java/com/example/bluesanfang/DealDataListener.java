package com.example.bluesanfang;

/**
 * Created by TanJieXi on 2018/3/28.
 */

/**
 * 处理数据的回调
 */
public interface DealDataListener {
    void onFetch(int code, String message);
}
